// This file does nothing - it is just for testing where
// the launcher looks for a github-badge.js file in the same folder
// as the launcher file.